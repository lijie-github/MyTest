// $(function () {
//     // 获取学生选择题得分的sapn标签
//     var stuScoreSpan = $(".stuScore");
//     // json, 记录学生选择题的分值，{"id":'score'}
//     choiceScores.each(function () {
//         var self = $(this);
//
//     });
//     var li = stuScoreSpan.parent().parent().parent().parent();
//
//     stuScoreSpan
//     console.log(stuScoreSpan);
// });